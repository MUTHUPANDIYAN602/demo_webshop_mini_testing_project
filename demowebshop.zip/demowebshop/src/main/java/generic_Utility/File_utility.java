package generic_Utility;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class File_utility {
	public static String getProperty(String key) {
		FileInputStream fis = null;
		try {
			fis = new FileInputStream("./src/main/resources/commondata.properties");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
				Properties property = new Properties();
				try {
					property.load(fis);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				return property.getProperty(key);
			}
}
