package checkout;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Checkout_with_missing_required_address_fields {
		public static void main(String[] args) throws InterruptedException {
			WebDriver driver = new ChromeDriver();
			driver.get("https://demowebshop.tricentis.com/");
			driver.manage().window().maximize();
			Thread.sleep(2000);
			driver.findElement(By.linkText("Log in")).click();
			driver.findElement(By.id("Email")).sendKeys("kmuthupandiyan602@gmail.com");
			driver.findElement(By.id("Password")).sendKeys("Pandiyan@1");
			driver.findElement(By.id("RememberMe")).click();
			driver.findElement(By.cssSelector("[value='Log in']")).click();
			Thread.sleep(2000);
			driver.findElement(By.partialLinkText("APPAREL & SHOES")).click();
			Thread.sleep(2000);
			driver.findElement(By.partialLinkText("Next")).click();
			Thread.sleep(2000);
			driver.findElement(By.partialLinkText("Men's Wrinkle Free Long Sleeve")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id=\"addtocart_10_EnteredQuantity\"]")).clear();
			driver.findElement(By.xpath("//*[@id=\"addtocart_10_EnteredQuantity\"]")).sendKeys("5");
			driver.findElement(By.xpath("//*[@id=\"add-to-cart-button-10\"]")).click();
			System.out.println("test case passed");
			System.out.println();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//input[@id='add-to-cart-button-10']")).click();
			Thread.sleep(2000);
			driver.findElement(By.partialLinkText("cart")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id=\"termsofservice\"]")).click();
			driver.findElement(By.xpath("//*[@id=\"checkout\"]")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id=\"billing-address-select\"]")).click();
			driver.findElement(By.xpath("//*[@id=\"billing-address-select\"]/option[2]")).click();
			driver.findElement(By.xpath("//*[@id=\"billing-buttons-container\"]/input")).click();
			Thread.sleep(2000);
			System.out.println(driver.findElement(By.xpath("//div[@class='enter-address']")).getText());
	driver.quit();
		}

}


