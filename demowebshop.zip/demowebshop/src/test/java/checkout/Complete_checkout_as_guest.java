package checkout;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Complete_checkout_as_guest {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://demowebshop.tricentis.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.findElement(By.partialLinkText("COMPUTERS")).click();
		driver.findElement(By.partialLinkText("Desktops")).click();
		driver.findElement(By.partialLinkText("Build your own computer")).click();
		driver.findElement(By.xpath("//select[@id=\"product_attribute_16_6_5\"]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"product_attribute_16_6_5\"]/option[3]")).click();
		driver.findElement(By.xpath("//*[@id=\"product_attribute_16_3_6_19\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"add-to-cart-button-16\"]")).click();
		Thread.sleep(2000);
		driver.findElement(By.partialLinkText("cart")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"termsofservice\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"checkout\"]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@class=\"button-1 checkout-as-guest-button\"]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class=\"text-box single-line\"])[1]")).sendKeys("logeshwaran");
		driver.findElement(By.xpath("(//input[@class=\"text-box single-line\"])[2]")).sendKeys("baskar");
		driver.findElement(By.xpath("//*[@id=\"BillingNewAddress_Email\"]")).sendKeys("blogeswaran1234@gmail.com");
		driver.findElement(By.xpath("//*[@id=\"BillingNewAddress_Company\"]")).sendKeys("logu computers");
		driver.findElement(By.xpath("//*[@id=\"BillingNewAddress_CountryId\"]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"BillingNewAddress_CountryId\"]/option[99]")).click();
		driver.findElement(By.xpath("//*[@id=\"BillingNewAddress_City\"]")).sendKeys("chidambaram");
		driver.findElement(By.xpath("//*[@id=\"BillingNewAddress_Address1\"]")).sendKeys("14,ECR , east rail road");
		driver.findElement(By.xpath("//*[@id=\"BillingNewAddress_ZipPostalCode\"]")).sendKeys("608001");
		driver.findElement(By.xpath("//*[@id=\"BillingNewAddress_PhoneNumber\"]")).sendKeys("9081726345");
		driver.findElement(By.xpath("//*[@id=\"billing-buttons-container\"]/input")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"PickUpInStore\"]")).click();//*[@id="shipping-buttons-container"]/input
		driver.findElement(By.xpath("//*[@id=\"shipping-buttons-container\"]/input")).click();
		driver.findElement(By.xpath("//*[@id=\"shipping-buttons-container\"]/input")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"payment-method-buttons-container\"]/input")).click();
		System.out.println(driver.findElement(By.xpath("//*[@id=\"checkout-step-confirm-order\"]")).getText());
		System.out.println();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@class='button-1 payment-info-next-step-button']")).click();
		Thread.sleep(2000);
		System.out.println();
		System.out.println(driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div")).getText());
		driver.findElement(By.xpath("//*[@id=\"confirm-order-buttons-container\"]/input")).click();
		Thread.sleep(2000);
		System.out.println(driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div/div/div[2]")).getText());
		driver.findElement(By.xpath("//a[text()='Click here for order details.']")).click();
		Thread.sleep(2000);
		System.out.println();
		System.out.println(driver.findElement(By.xpath("//div[@class='page-body']")).getText());
		driver.findElement(By.xpath("//a[text()='PDF Invoice']")).click();
		Thread.sleep(2000);
		driver.quit();
	}
}
