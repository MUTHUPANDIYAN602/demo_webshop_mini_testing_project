package checkout;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Verify_shipping_method_affects_total {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://demowebshop.tricentis.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.findElement(By.linkText("Log in")).click();
		driver.findElement(By.id("Email")).sendKeys("kmuthupandiyan602@gmail.com");
		driver.findElement(By.id("Password")).sendKeys("Pandiyan@1");
		driver.findElement(By.id("RememberMe")).click();
		driver.findElement(By.cssSelector("[value='Log in']")).click();
		Thread.sleep(2000);
		driver.findElement(By.partialLinkText("APPAREL & SHOES")).click();
		driver.findElement(By.partialLinkText("Next")).click();
		Thread.sleep(2000);
		driver.findElement(By.partialLinkText("Men's Wrinkle Free Long Sleeve")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"addtocart_10_EnteredQuantity\"]")).clear();
		driver.findElement(By.xpath("//*[@id=\"addtocart_10_EnteredQuantity\"]")).sendKeys("5");
		driver.findElement(By.xpath("//*[@id=\"add-to-cart-button-10\"]")).click();
		System.out.println("test case passed");
		System.out.println();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='add-to-cart-button-10']")).click();
		Thread.sleep(2000);
		driver.findElement(By.partialLinkText("cart")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"termsofservice\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"checkout\"]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"billing-address-select\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"billing-address-select\"]/option[2]")).click();
		driver.findElement(By.xpath("//*[@id=\"BillingNewAddress_Company\"]")).sendKeys("muthu computer");
		driver.findElement(By.xpath("//*[@id=\"BillingNewAddress_CountryId\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"BillingNewAddress_CountryId\"]/option[99]")).click();
		driver.findElement(By.xpath("//*[@id=\"BillingNewAddress_City\"]")).sendKeys("cuddalore");
		driver.findElement(By.xpath("//*[@id=\"BillingNewAddress_Address1\"]")).sendKeys("14, old town , main road");
		driver.findElement(By.xpath("//*[@id=\"BillingNewAddress_ZipPostalCode\"]")).sendKeys("606002");
		driver.findElement(By.xpath("//*[@id=\"BillingNewAddress_PhoneNumber\"]")).sendKeys("9045678389");
		driver.findElement(By.xpath("//*[@id=\"billing-buttons-container\"]/input")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div/div/div[2]/ol/li[2]/div[2]/div/input")).click();
		Thread.sleep(2000);
		//*[@id="shipping-buttons-container"]/input
		driver.findElement(By.xpath("//input[@id='shippingoption_1']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("(//*[@type='button'])[4]")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("(//*[@type='button'])[5]")).click();
		//System.out.println(driver.findElement(By.xpath("//*[@id=\"checkout-step-confirm-order\"]")).getText());
		System.out.println();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//*[@type='button'])[6]")).click();
		Thread.sleep(2000);
		System.out.println();	
		driver.findElement(By.xpath("(//*[@type='button'])[7]")).click();
		System.out.println(driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div/div/div[2]")).getText());
		Thread.sleep(3000);
		driver.findElement(By.xpath("//a[text()='Click here for order details.']")).click();
		Thread.sleep(2000);
		System.out.println();
		System.out.println(driver.findElement(By.xpath("//div[@class='page-body']")).getText());
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[text()='PDF Invoice']")).click();
		Thread.sleep(2000);
		//driver.quit();	
}
}