package home_Page_and_navigation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Category_Navigation {
	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demowebshop.tricentis.com/");
		driver.findElement(By.linkText("BOOKS")).click();
		if (driver.getTitle().contains("Books")) {
			System.out.println("books page displayed");
		} else {
			System.out.println("failed");
		}
		driver.findElement(By.linkText("COMPUTERS")).click();
		if (driver.getTitle().contains("Computers")) {
			System.out.println("computers page displayed");
		} else {
			System.out.println("failed");
		}
		driver.findElement(By.linkText("ELECTRONICS")).click();
		if (driver.getTitle().contains("Electronics")) {
			System.out.println("electronics page displayed");
		} else {
			System.out.println("failed");
		}
		driver.findElement(By.partialLinkText("SHOES")).click();
		if (driver.getTitle().contains("Shoes")) {
			System.out.println("shoes page displayed");
		} else {
			System.out.println("failed");
		}
		driver.findElement(By.partialLinkText("DIGITAL")).click();
		if (driver.getTitle().contains("Digital")) {
			System.out.println("digital page displayed");
		} else {
			System.out.println("failed");
		}
		driver.findElement(By.linkText("JEWELRY")).click();
		if (driver.getTitle().contains("Jewelry")) {
			System.out.println("jewelry page displayed");
		} else {
			System.out.println("failed");
		}
		driver.findElement(By.partialLinkText("CARDS")).click();
		if (driver.getTitle().contains("Cards")) {
			System.out.println("cards page displayed");
		} else {
			System.out.println("failed");
		}
	}
}
