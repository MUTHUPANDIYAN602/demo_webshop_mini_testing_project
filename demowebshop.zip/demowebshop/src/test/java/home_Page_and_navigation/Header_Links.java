package home_Page_and_navigation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Header_Links {
	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demowebshop.tricentis.com/");
		driver.findElement(By.partialLinkText("Register")).click();
		if (driver.getCurrentUrl().contains("register")) {
			System.out.println("rgister page is displayed");
		} else {
			System.out.println("rgister page is not  displayed");
		}
		driver.findElement(By.partialLinkText("Log in")).click();
		if (driver.getCurrentUrl().contains("login")) {
			System.out.println("login page is displayed");
		} else {
			System.out.println("login page is not displayed");
		}
		driver.findElement(By.partialLinkText("cart")).click();
		if (driver.getCurrentUrl().contains("cart")) {
			System.out.println("shopping cart page is displayed");
		} else {
			System.out.println("shoping cart page is not displayed");
		}
			driver.findElement(By.partialLinkText("list")).click();
			if (driver.getCurrentUrl().contains("wishlist")) {
				System.out.println("wish list page is displayed");
			} else {
				System.out.println("wish list page is not displayed");
			}
			driver.quit();
		}
		
	}


