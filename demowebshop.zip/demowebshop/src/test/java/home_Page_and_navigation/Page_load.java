package home_Page_and_navigation;
// tc 1
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Page_load {
	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demowebshop.tricentis.com/");
		if (driver.getTitle().contains("Demo Web Shop")) {
			System.out.println("success");
			Boolean head = 
		driver.findElement(By.className("header")).isDisplayed(); 
			if (head) {
				System.out.println("header display success");	
			} else {
				System.out.println("header display faild");
			}
		 Boolean menu = driver.findElement(By.className("top-menu")).isDisplayed();
		 if (menu) {
			System.out.println("top menu displayed success");
		} else {
			System.out.println("top menu displayed faild");
		}
		Boolean footer = driver.findElement(By.className("footer")).isDisplayed();
		if (footer) {
			System.out.println("footer displayed success");
		} else {
			System.out.println("footer displayed faild");

		}
		
		}
	    
	}
	

}
