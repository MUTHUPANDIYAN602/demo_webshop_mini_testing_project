package login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Logout {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://demowebshop.tricentis.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.findElement(By.linkText("Log in")).click();
		driver.findElement(By.id("Email")).sendKeys("kmuthupandiyan602@gmail.com");
		driver.findElement(By.id("Password")).sendKeys("Pandiyan@1");
		driver.findElement(By.id("RememberMe")).click();
		driver.findElement(By.cssSelector("[value='Log in']")).click();
		Thread.sleep(3000);
		driver.findElement(By.partialLinkText("Log out")).click();
		Thread.sleep(2000);
		String a = driver.findElement(By.linkText("Log in")).getText();
		String b = "Log in";
		if (a.contains(b)) {
		System.out.println("test case passed ");
		System.out.println(a +" is displayed");
		} else {
			System.out.println("test case falied");
			System.out.println(a +" link is displayed");
		}
		Thread.sleep(1000);
		String c = driver.findElement(By.partialLinkText("Register")).getText();
		String d = "Register";
		if (c.contains(d)) {
			System.out.println("test case passed ");
			System.out.println(c+" link is displayed");
		} else {
			System.out.println("test case failed");
		}
		driver.quit();
}
}
