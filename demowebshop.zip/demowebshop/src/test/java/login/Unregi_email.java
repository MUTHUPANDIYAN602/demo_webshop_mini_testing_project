package login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Unregi_email {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://demowebshop.tricentis.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.findElement(By.linkText("Log in")).click();
		driver.findElement(By.id("Email")).sendKeys("kmuthupandiyank111@gmail.com");
		driver.findElement(By.id("Password")).sendKeys("Pandiyan@1");
		Thread.sleep(2000);
		driver.findElement(By.id("RememberMe")).click();
		driver.findElement(By.cssSelector("[value='Log in']")).click();
		Thread.sleep(2000);
		String a = driver.findElement(By.xpath("//li[text()='No customer account found']")).getText(); 
		String b = "No customer account found";
		if (a.equals(b)) {
			System.out.println("test case passed ");
			System.out.println("error message : "+a);
			
		} else {
			System.out.println("test case failed");
			System.out.println("message :"+a);
		}
		Thread.sleep(2000);
		driver.quit();
	}
}
