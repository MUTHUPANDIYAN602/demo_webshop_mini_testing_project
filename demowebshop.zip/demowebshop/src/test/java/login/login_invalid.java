package login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class login_invalid {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://demowebshop.tricentis.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.findElement(By.linkText("Log in")).click();
		driver.findElement(By.id("Email")).sendKeys("kmuthupandiyan602@gmail.com");
		driver.findElement(By.id("Password")).sendKeys("Pandiyan");
		driver.findElement(By.id("RememberMe")).click();
		driver.findElement(By.cssSelector("[value='Log in']")).click();
		Thread.sleep(2000);
		String a = driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
		String b = "The credentials provided are incorrect";
		if (a.equals(b)) {
			System.out.println("failed");
			System.out.println("error message : "+ a);
		} else {
			System.out.println("passed");
			System.out.println("actual message : "+a);
		}
		driver.quit();
	}
}