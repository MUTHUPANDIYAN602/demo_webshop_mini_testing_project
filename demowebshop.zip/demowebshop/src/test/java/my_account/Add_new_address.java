package my_account;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Add_new_address {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://demowebshop.tricentis.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.findElement(By.linkText("Log in")).click();
		driver.findElement(By.id("Email")).sendKeys("kmuthupandiyan602@gmail.com");
		driver.findElement(By.id("Password")).sendKeys("Pandiyan@1");
		driver.findElement(By.id("RememberMe")).click();
		driver.findElement(By.cssSelector("[value='Log in']")).click();
		Thread.sleep(2000);
		driver.findElement(By.linkText("Addresses")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@class='button-1 add-address-button']")).click(); 
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='text-box single-line'])[1]")).sendKeys("logesh");
		driver.findElement(By.xpath("(//input[@class='text-box single-line'])[2]")).sendKeys("baskar");
		driver.findElement(By.id("Address_Email")).sendKeys("blogeswaran1234@gmail.com");
		driver.findElement(By.id("Address_Company")).sendKeys("vishnu store");
		driver.findElement(By.id("Address_CountryId")).click();
		driver.findElement(By.xpath("//option[@value='41']")).click();
		driver.findElement(By.id("Address_City")).sendKeys("sethiyathoppu");
		driver.findElement(By.id("Address_Address1")).sendKeys("14, east street , solatharam");
		driver.findElement(By.id("Address_ZipPostalCode")).sendKeys("606008");
		driver.findElement(By.id("Address_PhoneNumber")).sendKeys("9047787654");
		driver.findElement(By.xpath("//input[@class='button-1 save-address-button']")).click();
		Thread.sleep(5000);
		System.out.println(driver.findElement(By.xpath("//div[@class='center-2']")).getText());
		Thread.sleep(2000);
		driver.quit();
	}

}
