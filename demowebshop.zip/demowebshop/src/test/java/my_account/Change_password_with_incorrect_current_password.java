package my_account;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Change_password_with_incorrect_current_password  {
public static void main(String[] args) throws InterruptedException{
	WebDriver driver = new ChromeDriver();
	driver.get("https://demowebshop.tricentis.com/");
	driver.manage().window().maximize();
	Thread.sleep(2000);
	driver.findElement(By.linkText("Log in")).click();
	driver.findElement(By.id("Email")).sendKeys("kmuthupandiyan602@gmail.com");
	driver.findElement(By.id("Password")).sendKeys("Pandiyan@1");
	driver.findElement(By.id("RememberMe")).click();
	driver.findElement(By.cssSelector("[value='Log in']")).click();
	Thread.sleep(2000);
	driver.findElement(By.linkText("My account")).click();
	Thread.sleep(2000);
	driver.findElement(By.linkText("Change password")).click();
	Thread.sleep(2000);
	driver.findElement(By.id("OldPassword")).sendKeys("Pandiyan");
	driver.findElement(By.id("NewPassword")).sendKeys("Pandiyan@1");
	driver.findElement(By.id("ConfirmNewPassword")).sendKeys("Pandiyan@1");
	driver.findElement(By.xpath("//input[@class='button-1 change-password-button']")).click();
	Thread.sleep(2000);
	System.out.println(driver.findElement(By.xpath("(//li)[36]")).getText());
	driver.quit();
	
}
}
