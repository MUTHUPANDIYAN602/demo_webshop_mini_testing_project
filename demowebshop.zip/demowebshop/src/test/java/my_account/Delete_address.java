package my_account;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Delete_address {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://demowebshop.tricentis.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.findElement(By.linkText("Log in")).click();
		driver.findElement(By.id("Email")).sendKeys("kmuthupandiyan602@gmail.com");
		driver.findElement(By.id("Password")).sendKeys("Pandiyan@1");
		driver.findElement(By.id("RememberMe")).click();
		driver.findElement(By.cssSelector("[value='Log in']")).click();
		Thread.sleep(2000);
		driver.findElement(By.linkText("Addresses")).click();
		Thread.sleep(2000);
		System.out.println(driver.findElement(By.xpath("//div[@class='center-2']")).getText());
		System.out.println();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='button-2 delete-address-button'])[2]")).click();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(20000);
		driver.navigate().back();
		driver.navigate().forward();
		driver.navigate().refresh();
		Thread.sleep(2000);
		System.out.println("after delete");
		System.out.println();
		System.out.println(driver.findElement(By.xpath("//div[@class='center-2']")).getText());
		Thread.sleep(2000);
		driver.quit();
	}
	
}
