package my_account;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Update_account_information {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://demowebshop.tricentis.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.findElement(By.linkText("Log in")).click();
		driver.findElement(By.id("Email")).sendKeys("kmuthupandiyan602@gmail.com");
		driver.findElement(By.id("Password")).sendKeys("Pandiyan@1");
		driver.findElement(By.id("RememberMe")).click();
		driver.findElement(By.cssSelector("[value='Log in']")).click();
		Thread.sleep(2000);
		driver.findElement(By.linkText("My account")).click();
		Thread.sleep(2000);
		System.out.println(driver.findElement(By.xpath("//div[@class='page account-page customer-info-page']")).getText());
		driver.findElement(By.id("FirstName")).clear();
		driver.findElement(By.id("FirstName")).sendKeys("MUTHU");
		driver.findElement(By.id("LastName")).clear();
		driver.findElement(By.id("LastName")).sendKeys("PANDIYAN");
		driver.findElement(By.xpath("//input[@value='Save']")).click();
		System.out.println(driver.findElement(By.xpath("//div[@class='page account-page customer-info-page']")).getText());
		Thread.sleep(2000);
		driver.quit();
	}

}

