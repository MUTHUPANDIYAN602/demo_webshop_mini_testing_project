package newsletter_Subscription;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Subscribe_with_invalid_email_format {
	public static void main(String[] args)throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://demowebshop.tricentis.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.findElement(By.id("newsletter-email")).sendKeys("mutgmail.com");
		driver.findElement(By.id("newsletter-subscribe-button")).click();
		System.out.println(driver.findElement(By.id("newsletter-result-block")).getText());
}
}