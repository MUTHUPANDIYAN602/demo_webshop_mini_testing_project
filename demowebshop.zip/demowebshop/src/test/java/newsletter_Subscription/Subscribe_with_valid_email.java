package newsletter_Subscription;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Subscribe_with_valid_email {
	public static void main(String[] args)throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://demowebshop.tricentis.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.findElement(By.id("newsletter-email")).sendKeys("muthu@gmail.com");
		driver.findElement(By.id("newsletter-subscribe-button")).click();
		Thread.sleep(2000);
		System.out.println(driver.findElement(By.id("newsletter-result-block")).getText());
		driver.quit();
}
}
