package product_Catalog_and_Search;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Advanced_search {
		public static void main(String[] args) throws InterruptedException {
			WebDriver driver = new ChromeDriver();
			driver.get("https://demowebshop.tricentis.com/");
			driver.manage().window().maximize();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id=\"small-searchterms\"]")).sendKeys("com");
			driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[3]/form/input[2]")).click();
			driver.findElement(By.xpath("//*[@id=\"As\"]")).click();
			driver.findElement(By.xpath("//*[@id=\"Isc\"]")).click();
			driver.findElement(By.xpath("//*[@id=\"Sid\"]")).click();
			driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/form/div[3]/input")).click();
			System.out.println("page no: 1");
			System.out.println(driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[3]/div[1]")).getText());
			driver.findElement(By.partialLinkText("Next")).click();
			Thread.sleep(2000);
			System.out.println();
			System.out.println("page no: 2");
			System.out.println(driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[3]/div[1]")).getText());
			driver.findElement(By.partialLinkText("Next")).click();
			Thread.sleep(2000);
			System.out.println();
			System.out.println("page no: 3");
			System.out.println(driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[3]/div[1]")).getText());
			driver.findElement(By.partialLinkText("Next")).click();
			Thread.sleep(2000);
			System.out.println();
			System.out.println("page no: 4");
			System.out.println(driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[3]/div[1]")).getText());
			Thread.sleep(2000);
			driver.quit();
	}

}
