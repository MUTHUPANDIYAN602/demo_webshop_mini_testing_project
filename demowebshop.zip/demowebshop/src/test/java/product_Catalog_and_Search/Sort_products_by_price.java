package product_Catalog_and_Search;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Sort_products_by_price {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://demowebshop.tricentis.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.navigate().to("https://demowebshop.tricentis.com/books");
		driver.findElement(By.xpath("//*[@id=\"products-orderby\"]")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"products-orderby\"]/option[5]")).click();	
		System.out.println(driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[3]")).getText());
}
}