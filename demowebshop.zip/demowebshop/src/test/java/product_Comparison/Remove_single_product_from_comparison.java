package product_Comparison;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Remove_single_product_from_comparison {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://demowebshop.tricentis.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.findElement(By.partialLinkText("APPAREL & SHOES")).click();
		driver.findElement(By.partialLinkText("Next")).click();
		Thread.sleep(2000);
		driver.findElement(By.partialLinkText("Men's Wrinkle Free Long Sleeve")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@value=\"Add to compare list\"]")).click();
		Thread.sleep(2000);
		System.out.println(driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div")).getText());
		Thread.sleep(2000);
		driver.findElement(By.linkText("JEWELRY")).click();
		driver.findElement(By.partialLinkText("Black")).click();
		driver.findElement(By.xpath("//input[@value=\"Add to compare list\"]")).click();
		Thread.sleep(2000);
		System.out.println();
		System.out.println(driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div")).getText());
		Thread.sleep(2000);
		driver.findElement(By.partialLinkText("COMPUTERS")).click();
		driver.findElement(By.partialLinkText("Desktops")).click();
		driver.findElement(By.partialLinkText("Build your own computer")).click();
		driver.findElement(By.xpath("//input[@value=\"Add to compare list\"]")).click();
		Thread.sleep(2000);
		System.out.println();
		System.out.println(driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div")).getText());
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@value=\"Remove\"])[2]")).click();
		Thread.sleep(2000);
		System.out.println();
		System.out.println(driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div")).getText());
		Thread.sleep(2000);
		driver.quit();
}
}
