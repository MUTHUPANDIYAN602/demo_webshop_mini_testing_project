package product_Details_Page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Quantity_add {
		public static void main(String[] args) throws InterruptedException {
			WebDriver driver = new ChromeDriver();
			driver.get("https://demowebshop.tricentis.com/");
			driver.manage().window().maximize();
			Thread.sleep(2000);
			driver.findElement(By.partialLinkText("APPAREL & SHOES")).click();
			driver.findElement(By.partialLinkText("Next")).click();
			Thread.sleep(2000);
			driver.findElement(By.partialLinkText("Men's Wrinkle Free Long Sleeve")).click();
			driver.findElement(By.xpath("//*[@id=\"addtocart_10_EnteredQuantity\"]")).clear();
			driver.findElement(By.xpath("//*[@id=\"addtocart_10_EnteredQuantity\"]")).sendKeys("5");
			driver.findElement(By.xpath("//*[@id=\"add-to-cart-button-10\"]")).click();
			System.out.println("test case passed");
			System.out.println();
			Thread.sleep(2000);
			System.out.println(driver.findElement(By.xpath("/html/body/div[3]/p")).getText());
			Thread.sleep(3000);
			String a = driver.findElement(By.xpath("//*[@id=\"topcartlink\"]/a/span[1]")).getText();
			String b = driver.findElement(By.xpath("//*[@id=\"topcartlink\"]/a/span[2]")).getText();
			System.out.println();
			System.out.println(a+b);
			driver.quit();
		}
}
