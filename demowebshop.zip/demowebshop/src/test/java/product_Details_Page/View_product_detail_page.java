package product_Details_Page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class View_product_detail_page {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://demowebshop.tricentis.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.findElement(By.partialLinkText("APPAREL & SHOES")).click();
		driver.findElement(By.partialLinkText("Next")).click();
		Thread.sleep(2000);
		driver.findElement(By.partialLinkText("Men's Wrinkle Free Long Sleeve")).click();
		System.out.println(driver.findElement(By.xpath("//*[@id=\"product-details-form\"]/div/div[1]")).getText());
		Thread.sleep(2000);
		driver.quit();
	}
}