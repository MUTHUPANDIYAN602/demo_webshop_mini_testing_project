package product_Reviews_rating;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Submit_review_with_empty_fields {
	public static void main(String[] args)throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://demowebshop.tricentis.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.findElement(By.linkText("Log in")).click();
		driver.findElement(By.id("Email")).sendKeys("kmuthupandiyan602@gmail.com");
		driver.findElement(By.id("Password")).sendKeys("Pandiyan@1");
		driver.findElement(By.id("RememberMe")).click();
		driver.findElement(By.cssSelector("[value='Log in']")).click();
		Thread.sleep(2000);
		driver.findElement(By.partialLinkText("APPAREL & SHOES")).click();
		driver.findElement(By.partialLinkText("Next")).click();
		Thread.sleep(2000);
		driver.findElement(By.partialLinkText("Men's Wrinkle Free Long Sleeve")).click();
		Thread.sleep(2000);
		driver.findElement(By.partialLinkText("Add your review")).click();
		Thread.sleep(3000);
		driver.findElement(By.id("AddProductReview_Title")).sendKeys("");
		driver.findElement(By.id("AddProductReview_ReviewText")).sendKeys("");
		driver.findElement(By.xpath("//input[@class='button-1 write-product-review-button']")).click();
		Thread.sleep(2000);
		System.out.println(driver.findElement(By.xpath("(//span[@class='field-validation-error'])[1]")).getText());
		Thread.sleep(2000);
		System.out.println();
		System.out.println(driver.findElement(By.xpath("(//span[@class='field-validation-error'])[2]")).getText());
		driver.quit();
	}
	
}
