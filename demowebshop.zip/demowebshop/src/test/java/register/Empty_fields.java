package register;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Empty_fields {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://demowebshop.tricentis.com/");
		driver.manage().window().maximize();
		driver.findElement(By.partialLinkText("Register")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("register-button")).click();
		String  a = driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/form/div/div[2]/div[2]/div[2]/div[2]/span[2]/span")).getText();
		String b = "First name is required.";
		if (a.equals(b)) {
			System.out.println("passed");
			System.out.println("error message : "+a);
		} else {
			System.out.println("failed");
			System.out.println("actual message : "+a);
		}
		driver.quit();
}
}