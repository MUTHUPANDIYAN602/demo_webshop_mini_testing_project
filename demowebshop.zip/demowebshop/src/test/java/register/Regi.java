package register;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Regi {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://demowebshop.tricentis.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.findElement(By.partialLinkText("Register")).click();
		driver.findElement(By.id("gender-male")).click();
		driver.findElement(By.id("FirstName")).sendKeys("muthu");
		driver.findElement(By.id("LastName")).sendKeys("pandiyan");
		driver.findElement(By.id("Email")).sendKeys("kmuthupandiyan602@gmail.com");
		driver.findElement(By.id("Password")).sendKeys("Pandiyan@1");
		driver.findElement(By.id("ConfirmPassword")).sendKeys("Pandiyan@1");
		driver.findElement(By.id("register-button")).click();
	}

}
