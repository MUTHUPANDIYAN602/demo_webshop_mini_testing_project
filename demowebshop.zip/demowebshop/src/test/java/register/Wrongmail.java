package register;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Wrongmail {
	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
            driver.manage().window().maximize();
            driver.get("https://demowebshop.tricentis.com/");
            driver.findElement(By.linkText("Register")).click();
            driver.findElement(By.id("gender-male")).click();
            driver.findElement(By.id("FirstName")).sendKeys("Muthu");
            driver.findElement(By.id("LastName")).sendKeys("Pandiyan");
            driver.findElement(By.id("Email")).sendKeys("kmuthupandiyan602gmail.com");
            driver.findElement(By.id("Password")).sendKeys("Pandiyan@1");
            driver.findElement(By.id("ConfirmPassword")).sendKeys("Pandiyan@1");
            driver.findElement(By.id("register-button")).click();
            String a = driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/form/div/div[2]/div[2]/div[2]/div[4]/span[2]")).getText();
            String b = "Wrong email";
            if (a.equals(b)) {
				System.out.println("passed");
				System.out.println("error message : "+a);
			} else {
				System.out.println("failed ");
				System.out.println("actual message: "+a);
			}
            driver.quit();
}
}