package shopping_Cart;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Checkout_without_accepting_ToS {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://demowebshop.tricentis.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.findElement(By.partialLinkText("APPAREL & SHOES")).click();
		driver.findElement(By.partialLinkText("Next")).click();
		Thread.sleep(2000);
		driver.findElement(By.partialLinkText("Men's Wrinkle Free Long Sleeve")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"addtocart_10_EnteredQuantity\"]")).clear();
		driver.findElement(By.xpath("//*[@id=\"addtocart_10_EnteredQuantity\"]")).sendKeys("5");
		driver.findElement(By.xpath("//*[@id=\"add-to-cart-button-10\"]")).click();
		driver.findElement(By.xpath("//input [@id='add-to-cart-button-10']")).click();
		Thread.sleep(2000);
		driver.findElement(By.partialLinkText("Shopping")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"checkout\"]")).click();
		Thread.sleep(3000);
		System.out.println(driver.findElement(By.xpath("//*[@id=\"terms-of-service-warning-box\"]")).getText());
		driver.quit();
}
}