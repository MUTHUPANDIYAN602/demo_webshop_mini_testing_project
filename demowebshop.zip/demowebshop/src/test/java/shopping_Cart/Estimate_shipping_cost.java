package shopping_Cart;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Estimate_shipping_cost {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://demowebshop.tricentis.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.findElement(By.partialLinkText("APPAREL & SHOES")).click();
		driver.findElement(By.partialLinkText("Next")).click();
		Thread.sleep(2000);
		driver.findElement(By.partialLinkText("Men's Wrinkle Free Long Sleeve")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"addtocart_10_EnteredQuantity\"]")).clear();
		driver.findElement(By.xpath("//*[@id=\"addtocart_10_EnteredQuantity\"]")).sendKeys("5");
		driver.findElement(By.xpath("//*[@id=\"add-to-cart-button-10\"]")).click();
		driver.findElement(By.xpath("//input [@id='add-to-cart-button-10']")).click();
		Thread.sleep(2000);
		driver.findElement(By.partialLinkText("Shopping")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div/div/div[2]/div/form/div[2]/div[1]/div[2]/div/div[3]/div[1]\r\n")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"CountryId\"]/option[99]")).click();
		driver.findElement(By.xpath("//*[@id=\"ZipPostalCode\"]")).sendKeys("606108");
		driver.findElement(By.xpath("//*[@name='estimateshipping']")).click();
		System.out.println(driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div/div/div[2]/div/form/div[2]/div[1]/div[2]/div")).getText());
		System.out.println(driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div/div/div[2]/div/form/div[2]/div[2]")).getText());
		driver.quit();
	}
}