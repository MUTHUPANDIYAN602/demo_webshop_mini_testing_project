package shopping_Cart;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Update_item_quantity {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://demowebshop.tricentis.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.findElement(By.linkText("Log in")).click();
		driver.findElement(By.id("Email")).sendKeys("kmuthupandiyan602@gmail.com");
		driver.findElement(By.id("Password")).sendKeys("Pandiyan@1");
		driver.findElement(By.id("RememberMe")).click();
		driver.findElement(By.cssSelector("[value='Log in']")).click();
		Thread.sleep(2000);
		driver.findElement(By.partialLinkText("APPAREL & SHOES")).click();
		driver.findElement(By.partialLinkText("Next")).click();
		Thread.sleep(2000);
		driver.findElement(By.partialLinkText("Men's Wrinkle Free Long Sleeve")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"addtocart_10_EnteredQuantity\"]")).clear();
		driver.findElement(By.xpath("//*[@id=\"addtocart_10_EnteredQuantity\"]")).sendKeys("5");
		driver.findElement(By.xpath("//*[@id=\"add-to-cart-button-10\"]")).click();
		driver.findElement(By.xpath("//input [@id='add-to-cart-button-10']")).click();
		Thread.sleep(2000);
		driver.findElement(By.partialLinkText("Shopping")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div/div/div[2]/div/form/table/tbody/tr[1]/td[5]/input")).clear();
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div/div/div[2]/div/form/table/tbody/tr[1]/td[5]/input")).sendKeys("10");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@name='updatecart']")).click();
		Thread.sleep(2000);
		System.out.println(driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div")).getText());
		driver.quit();
	}
}
