package wishlist;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Empty_wishlist_message_for_guest {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://demowebshop.tricentis.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.navigate().to("https://demowebshop.tricentis.com/wishlist");
		Thread.sleep(2000);
		System.out.println(driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div/div")).getText());
		driver.quit();
}
}