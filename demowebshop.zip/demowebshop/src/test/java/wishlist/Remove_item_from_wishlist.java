package wishlist;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Remove_item_from_wishlist {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://demowebshop.tricentis.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.findElement(By.partialLinkText("APPAREL & SHOES")).click();
		driver.findElement(By.partialLinkText("Next")).click();
		Thread.sleep(2000);
		driver.findElement(By.partialLinkText("Men's Wrinkle Free Long Sleeve")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"addtocart_10_EnteredQuantity\"]")).clear();
		driver.findElement(By.xpath("//*[@id=\"addtocart_10_EnteredQuantity\"]")).sendKeys("5");
		driver.findElement(By.xpath("//*[@id=\"add-to-wishlist-button-10\"]")).click();
		Thread.sleep(2000);
		driver.navigate().to("https://demowebshop.tricentis.com/wishlist");
		Thread.sleep(2000);
		System.out.println(driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div")).getText());
		System.out.println();
		driver.findElement(By.xpath("//*[@name=\"removefromcart\"]")).click();
		driver.findElement(By.xpath("//*[@name=\"updatecart\"]")).click();
		Thread.sleep(2000);
		System.out.println(driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div/div")).getText());
		driver.quit();	

	
	
	}
}